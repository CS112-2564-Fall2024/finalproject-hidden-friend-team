import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class MovieDetailsController {
    @FXML
    private ImageView posterImageView;
    @FXML
    private Label titleLabel;
    @FXML
    private Label yearLabel;
    @FXML
    private Label plotLabel;
    @FXML
    private Label runtimeLabel;
    @FXML
    private Label actorsLabel;

    public void setMovieDetails(String title, String year, String plot, String runtime, String actors, String posterUrl) {
        titleLabel.setText(title);
        yearLabel.setText(year);
        plotLabel.setText(plot);
        runtimeLabel.setText(runtime);
        actorsLabel.setText(actors);

        // Load the poster image
        if (posterUrl != null && !posterUrl.equals("N/A")) {
            Image posterImage = new Image(posterUrl, true);
            posterImageView.setImage(posterImage);
        } else {
            posterImageView.setImage(new Image("https://via.placeholder.com/200x300.png?text=No+Poster"));
        }
    }
}