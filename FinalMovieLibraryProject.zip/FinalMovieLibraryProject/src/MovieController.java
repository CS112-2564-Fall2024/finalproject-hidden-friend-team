import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import java.io.File;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class MovieController {
    @FXML
    private TextField searchField;
    @FXML
    private TableView<Movie> movieTable;
    @FXML
    private TableColumn<Movie, String> titleColumn;
    @FXML
    private TableColumn<Movie, String> yearColumn;

    private final ObservableList<Movie> movies = FXCollections.observableArrayList();
    private final ObservableList<Movie> libraryMovies = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        titleColumn.setCellValueFactory(cellData -> cellData.getValue().titleProperty());
        yearColumn.setCellValueFactory(cellData -> cellData.getValue().yearProperty());
        movieTable.setItems(movies);
    }

    @FXML
    public void searchMovies() {
        String query = searchField.getText().trim();
        if (query.isEmpty()) {
            return;
        }

        String apiKey = "4e90e652";
        String apiUrl = "http://www.omdbapi.com/?s=" + query + "&apikey=" + apiKey;

        try {
            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(apiUrl))
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            JsonObject jsonResponse = JsonParser.parseString(response.body()).getAsJsonObject();

            if (jsonResponse.has("Search")) {
                ObservableList<Movie> searchMovies = FXCollections.observableArrayList();

                jsonResponse.getAsJsonArray("Search").forEach(item -> {
                    JsonObject movieJson = item.getAsJsonObject();
                    String title = movieJson.get("Title").getAsString();
                    String year = movieJson.get("Year").getAsString();
                    searchMovies.add(new Movie(title, year));
                });

                movies.setAll(searchMovies);
            } else {
                movies.clear();
                System.out.println("No results found.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void addToLibrary() {
        Movie selectedMovie = movieTable.getSelectionModel().getSelectedItem();
        if (selectedMovie != null && !libraryMovies.contains(selectedMovie)) {
            libraryMovies.add(selectedMovie);
            playSound("add_sound.wav");
        }
    }

    @FXML
    public void showLibrary() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/LibraryView.fxml"));
            Stage libraryStage = new Stage();
            libraryStage.setScene(new Scene(loader.load()));
            LibraryController controller = loader.getController();
            controller.setLibraryMovies(libraryMovies);
            libraryStage.setTitle("My Movie Library");
            libraryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void showDetails() {
        Movie selectedMovie = movieTable.getSelectionModel().getSelectedItem();
        if (selectedMovie != null) {
            String apiKey = "4e90e652";
            String apiUrl = "http://www.omdbapi.com/?t=" + selectedMovie.getTitle().replace(" ", "+") + "&apikey=" + apiKey;

            try {
                HttpClient client = HttpClient.newHttpClient();
                HttpRequest request = HttpRequest.newBuilder()
                        .uri(URI.create(apiUrl))
                        .build();

                HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
                JsonObject jsonResponse = JsonParser.parseString(response.body()).getAsJsonObject();

                if (jsonResponse.has("Title")) {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/MovieDetails.fxml"));
                    Stage detailsStage = new Stage();
                    detailsStage.setScene(new Scene(loader.load()));

                    MovieDetailsController controller = loader.getController();
                    controller.setMovieDetails(
                            jsonResponse.get("Title").getAsString(),
                            jsonResponse.get("Year").getAsString(),
                            jsonResponse.get("Plot").getAsString(),
                            jsonResponse.get("Runtime").getAsString(),
                            jsonResponse.get("Actors").getAsString(),
                            jsonResponse.get("Poster").getAsString()
                    );

                    detailsStage.setTitle("Movie Details");
                    detailsStage.show();
                } else {
                    System.out.println("Details not found.");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void playSound(String soundFile) {
        try {
            File file = new File("resources/sounds/" + soundFile);
            Clip clip = AudioSystem.getClip();
            clip.open(AudioSystem.getAudioInputStream(file));
            clip.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}