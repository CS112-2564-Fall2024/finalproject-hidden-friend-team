import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Movie {
    private final StringProperty title;
    private final StringProperty year;

    public Movie(String title, String year) {
        this.title = new SimpleStringProperty(title);
        this.year = new SimpleStringProperty(year);
    }

    public String getTitle() {
        return title.get();
    }

    public StringProperty titleProperty() {
        return title;
    }

    public String getYear() {
        return year.get();
    }

    public StringProperty yearProperty() {
        return year;
    }
}