import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.Button;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import java.io.File;

public class LibraryController {
    @FXML
    private TableView<Movie> libraryTable;
    @FXML
    private TableColumn<Movie, String> titleColumn;
    @FXML
    private TableColumn<Movie, String> yearColumn;
    @FXML
    private Button removeButton;

    public void setLibraryMovies(ObservableList<Movie> libraryMovies) {
        libraryTable.setItems(libraryMovies);
    }

    @FXML
    public void initialize() {
        titleColumn.setCellValueFactory(cellData -> cellData.getValue().titleProperty());
        yearColumn.setCellValueFactory(cellData -> cellData.getValue().yearProperty());
    }

    @FXML
    public void removeMovie() {
        Movie selectedMovie = libraryTable.getSelectionModel().getSelectedItem();
        if (selectedMovie != null) {
            libraryTable.getItems().remove(selectedMovie);
            playSound("remove_sound.wav");
        }
    }

    private void playSound(String soundFile) {
        try {
            File file = new File("resources/sounds/" + soundFile);
            Clip clip = AudioSystem.getClip();
            clip.open(AudioSystem.getAudioInputStream(file));
            clip.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}