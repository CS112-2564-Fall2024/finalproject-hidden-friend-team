import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import java.io.File;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        playStartupSound(); // Play the startup sound

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/MovieLibrary.fxml"));
        primaryStage.setScene(new Scene(loader.load()));
        primaryStage.setTitle("Movie Library");
        primaryStage.show();
    }

    private void playStartupSound() {
        try {
            File file = new File(getClass().getResource("/sounds/startup_sound.wav").toURI());
            Clip clip = AudioSystem.getClip();
            clip.open(AudioSystem.getAudioInputStream(file));
            clip.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}